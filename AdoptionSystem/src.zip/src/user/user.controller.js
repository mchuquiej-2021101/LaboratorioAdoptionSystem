'use strict'

export const test = (req, res) => {
    return res.send('Hello World')
}